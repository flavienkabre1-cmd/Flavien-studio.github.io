FLAVIEN STUDIO — FICHIER DE PRÉSENTATION

Ce dossier contient une page professionnelle de téléchargement pour l'application Flavien Studio.

Pour que le bouton fonctionne :
1. Place ton vrai fichier Android APK dans ce dossier.
2. Renomme-le exactement : flavien-studio.apk
3. Garde index.html dans le même dossier.
4. Sur GitHub Pages, le bouton permettra de télécharger l'APK.

Important : ce fichier HTML n'est pas lui-même une application Android. Pour installer l'application sur un téléphone, il faut le vrai fichier APK.
